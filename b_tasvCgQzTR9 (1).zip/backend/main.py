import os
import json
import secrets
import string
import hashlib
import base64
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path

from flask import Flask, request, jsonify
from flask_cors import CORS
import bcrypt
import jwt
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

app = Flask(__name__)
CORS(app, supports_credentials=True)

# Configuration
SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "your-super-secret-key-change-in-production")
DATA_DIR = Path("/tmp/password_wallet_data")
DATA_DIR.mkdir(exist_ok=True)

USERS_FILE = DATA_DIR / "users.json"
CREDENTIALS_FILE = DATA_DIR / "credentials.json"


def get_encryption_key(master_password: str, salt: bytes) -> bytes:
    """Derive encryption key from master password using PBKDF2"""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=480000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(master_password.encode()))
    return key


def encrypt_password(password: str, master_key: bytes) -> str:
    """Encrypt a password using Fernet symmetric encryption"""
    f = Fernet(master_key)
    encrypted = f.encrypt(password.encode())
    return base64.urlsafe_b64encode(encrypted).decode()


def decrypt_password(encrypted_password: str, master_key: bytes) -> str:
    """Decrypt a password using Fernet symmetric encryption"""
    f = Fernet(master_key)
    encrypted = base64.urlsafe_b64decode(encrypted_password.encode())
    decrypted = f.decrypt(encrypted)
    return decrypted.decode()


def load_users() -> dict:
    """Load users from file"""
    if USERS_FILE.exists():
        return json.loads(USERS_FILE.read_text())
    return {}


def save_users(users: dict):
    """Save users to file"""
    USERS_FILE.write_text(json.dumps(users, indent=2))


def load_credentials() -> dict:
    """Load credentials from file"""
    if CREDENTIALS_FILE.exists():
        return json.loads(CREDENTIALS_FILE.read_text())
    return {}


def save_credentials(credentials: dict):
    """Save credentials to file"""
    CREDENTIALS_FILE.write_text(json.dumps(credentials, indent=2))


def create_token(user_id: str, email: str) -> str:
    """Create JWT token"""
    payload = {
        "user_id": user_id,
        "email": email,
        "exp": datetime.utcnow() + timedelta(hours=24)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")


def token_required(f):
    """Decorator to require valid JWT token"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth_header = request.headers.get("Authorization")
        
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ")[1]
        
        if not token:
            return jsonify({"error": "Token is missing"}), 401
        
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            request.user_id = payload["user_id"]
            request.email = payload["email"]
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token has expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401
        
        return f(*args, **kwargs)
    return decorated


@app.route("/health")
def health():
    """Health check endpoint"""
    return jsonify({"status": "ok"})


@app.route("/auth/register", methods=["POST"])
def register():
    """Register a new user"""
    data = request.get_json()
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    name = data.get("name", "").strip()
    
    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400
    
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400
    
    users = load_users()
    
    if email in users:
        return jsonify({"error": "Email already registered"}), 409
    
    # Generate salt for password encryption key
    salt = os.urandom(16)
    
    # Hash the password for authentication
    password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    
    # Create user ID
    user_id = secrets.token_hex(16)
    
    users[email] = {
        "id": user_id,
        "name": name,
        "password_hash": password_hash,
        "salt": base64.urlsafe_b64encode(salt).decode(),
        "created_at": datetime.utcnow().isoformat()
    }
    
    save_users(users)
    
    token = create_token(user_id, email)
    
    return jsonify({
        "message": "User registered successfully",
        "token": token,
        "user": {
            "id": user_id,
            "email": email,
            "name": name
        }
    }), 201


@app.route("/auth/login", methods=["POST"])
def login():
    """Login user"""
    data = request.get_json()
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    
    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400
    
    users = load_users()
    
    if email not in users:
        return jsonify({"error": "Invalid email or password"}), 401
    
    user = users[email]
    
    if not bcrypt.checkpw(password.encode(), user["password_hash"].encode()):
        return jsonify({"error": "Invalid email or password"}), 401
    
    token = create_token(user["id"], email)
    
    return jsonify({
        "message": "Login successful",
        "token": token,
        "user": {
            "id": user["id"],
            "email": email,
            "name": user.get("name", "")
        }
    })


@app.route("/auth/me", methods=["GET"])
@token_required
def get_current_user():
    """Get current user info"""
    users = load_users()
    
    for email, user in users.items():
        if user["id"] == request.user_id:
            return jsonify({
                "id": user["id"],
                "email": email,
                "name": user.get("name", "")
            })
    
    return jsonify({"error": "User not found"}), 404


@app.route("/generate-password", methods=["POST"])
def generate_password():
    """Generate a secure random password"""
    data = request.get_json() or {}
    
    length = data.get("length", 16)
    include_uppercase = data.get("includeUppercase", True)
    include_lowercase = data.get("includeLowercase", True)
    include_numbers = data.get("includeNumbers", True)
    include_symbols = data.get("includeSymbols", True)
    
    # Validate length
    length = max(4, min(128, int(length)))
    
    # Build character set
    chars = ""
    if include_lowercase:
        chars += string.ascii_lowercase
    if include_uppercase:
        chars += string.ascii_uppercase
    if include_numbers:
        chars += string.digits
    if include_symbols:
        chars += "!@#$%^&*()_+-=[]{}|;:,.<>?"
    
    if not chars:
        chars = string.ascii_letters + string.digits
    
    # Generate password
    password = "".join(secrets.choice(chars) for _ in range(length))
    
    # Calculate password strength
    strength = calculate_password_strength(password)
    
    return jsonify({
        "password": password,
        "strength": strength
    })


def calculate_password_strength(password: str) -> dict:
    """Calculate password strength score and details"""
    score = 0
    feedback = []
    
    # Length check
    if len(password) >= 8:
        score += 1
    if len(password) >= 12:
        score += 1
    if len(password) >= 16:
        score += 1
    
    # Character variety
    has_lower = any(c.islower() for c in password)
    has_upper = any(c.isupper() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_symbol = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
    
    if has_lower:
        score += 1
    if has_upper:
        score += 1
    if has_digit:
        score += 1
    if has_symbol:
        score += 1
    
    # Feedback
    if len(password) < 12:
        feedback.append("Consider using at least 12 characters")
    if not has_symbol:
        feedback.append("Add special characters for extra security")
    if not (has_lower and has_upper):
        feedback.append("Mix uppercase and lowercase letters")
    
    # Determine strength level
    if score >= 6:
        level = "strong"
    elif score >= 4:
        level = "medium"
    else:
        level = "weak"
    
    return {
        "score": score,
        "maxScore": 7,
        "level": level,
        "feedback": feedback
    }


@app.route("/credentials", methods=["GET"])
@token_required
def get_credentials():
    """Get all credentials for the current user"""
    all_credentials = load_credentials()
    user_credentials = all_credentials.get(request.user_id, [])
    
    # Return credentials without decrypted passwords
    safe_credentials = []
    for cred in user_credentials:
        safe_credentials.append({
            "id": cred["id"],
            "website": cred["website"],
            "username": cred["username"],
            "notes": cred.get("notes", ""),
            "created_at": cred["created_at"],
            "updated_at": cred.get("updated_at", cred["created_at"])
        })
    
    return jsonify({"credentials": safe_credentials})


@app.route("/credentials", methods=["POST"])
@token_required
def create_credential():
    """Create a new credential"""
    data = request.get_json()
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    website = data.get("website", "").strip()
    username = data.get("username", "").strip()
    password = data.get("password", "")
    notes = data.get("notes", "").strip()
    master_password = data.get("masterPassword", "")
    
    if not website or not username or not password:
        return jsonify({"error": "Website, username, and password are required"}), 400
    
    if not master_password:
        return jsonify({"error": "Master password is required for encryption"}), 400
    
    # Get user's salt
    users = load_users()
    user = None
    for email, u in users.items():
        if u["id"] == request.user_id:
            user = u
            break
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Verify master password
    if not bcrypt.checkpw(master_password.encode(), user["password_hash"].encode()):
        return jsonify({"error": "Invalid master password"}), 401
    
    # Derive encryption key
    salt = base64.urlsafe_b64decode(user["salt"].encode())
    encryption_key = get_encryption_key(master_password, salt)
    
    # Encrypt password
    encrypted_password = encrypt_password(password, encryption_key)
    
    # Create credential
    credential_id = secrets.token_hex(16)
    credential = {
        "id": credential_id,
        "website": website,
        "username": username,
        "encrypted_password": encrypted_password,
        "notes": notes,
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat()
    }
    
    all_credentials = load_credentials()
    if request.user_id not in all_credentials:
        all_credentials[request.user_id] = []
    
    all_credentials[request.user_id].append(credential)
    save_credentials(all_credentials)
    
    return jsonify({
        "message": "Credential created successfully",
        "credential": {
            "id": credential_id,
            "website": website,
            "username": username,
            "notes": notes,
            "created_at": credential["created_at"]
        }
    }), 201


@app.route("/credentials/<credential_id>", methods=["GET"])
@token_required
def get_credential(credential_id):
    """Get a specific credential (without password)"""
    all_credentials = load_credentials()
    user_credentials = all_credentials.get(request.user_id, [])
    
    for cred in user_credentials:
        if cred["id"] == credential_id:
            return jsonify({
                "credential": {
                    "id": cred["id"],
                    "website": cred["website"],
                    "username": cred["username"],
                    "notes": cred.get("notes", ""),
                    "created_at": cred["created_at"],
                    "updated_at": cred.get("updated_at", cred["created_at"])
                }
            })
    
    return jsonify({"error": "Credential not found"}), 404


@app.route("/credentials/<credential_id>/decrypt", methods=["POST"])
@token_required
def decrypt_credential(credential_id):
    """Decrypt and return the password for a credential"""
    data = request.get_json()
    master_password = data.get("masterPassword", "") if data else ""
    
    if not master_password:
        return jsonify({"error": "Master password is required"}), 400
    
    # Get user's salt
    users = load_users()
    user = None
    for email, u in users.items():
        if u["id"] == request.user_id:
            user = u
            break
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Verify master password
    if not bcrypt.checkpw(master_password.encode(), user["password_hash"].encode()):
        return jsonify({"error": "Invalid master password"}), 401
    
    # Find credential
    all_credentials = load_credentials()
    user_credentials = all_credentials.get(request.user_id, [])
    
    for cred in user_credentials:
        if cred["id"] == credential_id:
            try:
                salt = base64.urlsafe_b64decode(user["salt"].encode())
                encryption_key = get_encryption_key(master_password, salt)
                decrypted_password = decrypt_password(cred["encrypted_password"], encryption_key)
                return jsonify({"password": decrypted_password})
            except Exception as e:
                return jsonify({"error": "Failed to decrypt password"}), 500
    
    return jsonify({"error": "Credential not found"}), 404


@app.route("/credentials/<credential_id>", methods=["PUT"])
@token_required
def update_credential(credential_id):
    """Update a credential"""
    data = request.get_json()
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    master_password = data.get("masterPassword", "")
    
    if not master_password:
        return jsonify({"error": "Master password is required"}), 400
    
    # Get user
    users = load_users()
    user = None
    for email, u in users.items():
        if u["id"] == request.user_id:
            user = u
            break
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Verify master password
    if not bcrypt.checkpw(master_password.encode(), user["password_hash"].encode()):
        return jsonify({"error": "Invalid master password"}), 401
    
    # Find and update credential
    all_credentials = load_credentials()
    user_credentials = all_credentials.get(request.user_id, [])
    
    for i, cred in enumerate(user_credentials):
        if cred["id"] == credential_id:
            # Update fields
            if "website" in data:
                cred["website"] = data["website"].strip()
            if "username" in data:
                cred["username"] = data["username"].strip()
            if "notes" in data:
                cred["notes"] = data["notes"].strip()
            if "password" in data and data["password"]:
                salt = base64.urlsafe_b64decode(user["salt"].encode())
                encryption_key = get_encryption_key(master_password, salt)
                cred["encrypted_password"] = encrypt_password(data["password"], encryption_key)
            
            cred["updated_at"] = datetime.utcnow().isoformat()
            user_credentials[i] = cred
            all_credentials[request.user_id] = user_credentials
            save_credentials(all_credentials)
            
            return jsonify({
                "message": "Credential updated successfully",
                "credential": {
                    "id": cred["id"],
                    "website": cred["website"],
                    "username": cred["username"],
                    "notes": cred.get("notes", ""),
                    "updated_at": cred["updated_at"]
                }
            })
    
    return jsonify({"error": "Credential not found"}), 404


@app.route("/credentials/<credential_id>", methods=["DELETE"])
@token_required
def delete_credential(credential_id):
    """Delete a credential"""
    data = request.get_json()
    master_password = data.get("masterPassword", "") if data else ""
    
    if not master_password:
        return jsonify({"error": "Master password is required"}), 400
    
    # Get user
    users = load_users()
    user = None
    for email, u in users.items():
        if u["id"] == request.user_id:
            user = u
            break
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Verify master password
    if not bcrypt.checkpw(master_password.encode(), user["password_hash"].encode()):
        return jsonify({"error": "Invalid master password"}), 401
    
    # Find and delete credential
    all_credentials = load_credentials()
    user_credentials = all_credentials.get(request.user_id, [])
    
    for i, cred in enumerate(user_credentials):
        if cred["id"] == credential_id:
            user_credentials.pop(i)
            all_credentials[request.user_id] = user_credentials
            save_credentials(all_credentials)
            return jsonify({"message": "Credential deleted successfully"})
    
    return jsonify({"error": "Credential not found"}), 404


# For local development
if __name__ == "__main__":
    app.run(debug=True, port=5000)
