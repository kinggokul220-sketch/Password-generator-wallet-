"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { AuthProvider, useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Spinner } from "@/components/ui/spinner"
import { PasswordGenerator } from "@/components/password-generator"
import { CredentialList } from "@/components/credential-list"
import { AddCredentialForm } from "@/components/add-credential-form"
import { type Credential } from "@/lib/api"
import { useSWRConfig } from "swr"
import { Shield, LogOut, Wand2, KeyRound, User } from "lucide-react"

function DashboardContent() {
  const router = useRouter()
  const { user, isLoading, logout } = useAuth()
  const { mutate } = useSWRConfig()
  const [editingCredential, setEditingCredential] = useState<Credential | null>(null)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  const handleCredentialSuccess = () => {
    mutate("credentials")
    setEditingCredential(null)
  }

  if (isLoading) {
    return (
      <main className="flex min-h-screen items-center justify-center">
        <Spinner className="h-8 w-8" />
      </main>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <span className="font-semibold text-lg">SecureVault</span>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
                <User className="h-4 w-4" />
                <span>{user.email}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            Welcome back{user.name ? `, ${user.name}` : ""}
          </h1>
          <p className="text-muted-foreground">
            Manage your passwords securely
          </p>
        </div>

        <Tabs defaultValue="vault" className="w-full">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <TabsList>
              <TabsTrigger value="vault">
                <KeyRound className="mr-2 h-4 w-4" />
                Password Vault
              </TabsTrigger>
              <TabsTrigger value="generator">
                <Wand2 className="mr-2 h-4 w-4" />
                Generator
              </TabsTrigger>
            </TabsList>
            
            <AddCredentialForm 
              onSuccess={handleCredentialSuccess}
              editingCredential={null}
            />
          </div>

          <TabsContent value="vault" className="mt-0">
            <div className="flex flex-col gap-6">
              {editingCredential && (
                <AddCredentialForm
                  onSuccess={handleCredentialSuccess}
                  editingCredential={editingCredential}
                  onCancelEdit={() => setEditingCredential(null)}
                />
              )}
              <CredentialList onEdit={setEditingCredential} />
            </div>
          </TabsContent>

          <TabsContent value="generator" className="mt-0">
            <div className="max-w-2xl">
              <PasswordGenerator />
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t py-6 mt-auto">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>Your passwords are encrypted with AES-256 encryption using your master password.</p>
          <p className="mt-1">Never share your master password with anyone.</p>
        </div>
      </footer>
    </div>
  )
}

export default function Dashboard() {
  return (
    <AuthProvider>
      <DashboardContent />
    </AuthProvider>
  )
}
