"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { AuthProvider, useAuth } from "@/lib/auth-context"
import { AuthForm } from "@/components/auth-form"
import { Spinner } from "@/components/ui/spinner"

function AuthPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && user) {
      router.push("/dashboard")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <main className="flex min-h-screen items-center justify-center">
        <Spinner className="h-8 w-8" />
      </main>
    )
  }

  if (user) {
    return null
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-gradient-to-br from-background via-background to-muted/30">
      <AuthForm />
      <p className="mt-8 text-center text-sm text-muted-foreground max-w-md">
        Your passwords are encrypted using your master password with industry-standard AES-256 encryption.
      </p>
    </main>
  )
}

export default function Home() {
  return (
    <AuthProvider>
      <AuthPage />
    </AuthProvider>
  )
}
