"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Spinner } from "@/components/ui/spinner"
import { createCredential, updateCredential, type Credential } from "@/lib/api"
import { PasswordGenerator } from "@/components/password-generator"
import { toast } from "sonner"
import { Plus, Save, Globe, User, Lock, FileText, X } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface AddCredentialFormProps {
  onSuccess: () => void
  editingCredential?: Credential | null
  onCancelEdit?: () => void
}

export function AddCredentialForm({ onSuccess, editingCredential, onCancelEdit }: AddCredentialFormProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [showGenerator, setShowGenerator] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  
  const [form, setForm] = useState({
    website: editingCredential?.website || "",
    username: editingCredential?.username || "",
    password: "",
    notes: editingCredential?.notes || "",
    masterPassword: "",
  })

  const isEditing = !!editingCredential

  const resetForm = () => {
    setForm({
      website: "",
      username: "",
      password: "",
      notes: "",
      masterPassword: "",
    })
    setShowGenerator(false)
  }

  const handleClose = () => {
    if (isEditing && onCancelEdit) {
      onCancelEdit()
    } else {
      setIsOpen(false)
    }
    resetForm()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!form.website || !form.username || !form.masterPassword) {
      toast.error("Please fill in all required fields")
      return
    }

    if (!isEditing && !form.password) {
      toast.error("Please provide a password")
      return
    }

    setIsLoading(true)

    try {
      if (isEditing && editingCredential) {
        await updateCredential(editingCredential.id, {
          website: form.website,
          username: form.username,
          password: form.password || undefined,
          notes: form.notes,
          masterPassword: form.masterPassword,
        })
        toast.success("Credential updated successfully")
      } else {
        await createCredential({
          website: form.website,
          username: form.username,
          password: form.password,
          notes: form.notes,
          masterPassword: form.masterPassword,
        })
        toast.success("Credential saved successfully")
      }
      handleClose()
      onSuccess()
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save credential")
    } finally {
      setIsLoading(false)
    }
  }

  const handleUseGeneratedPassword = (password: string) => {
    setForm({ ...form, password })
    setShowGenerator(false)
    toast.success("Password applied to form")
  }

  const formContent = (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col gap-2">
        <Label htmlFor="website">Website / Service *</Label>
        <div className="relative">
          <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            id="website"
            placeholder="e.g., github.com"
            className="pl-10"
            value={form.website}
            onChange={(e) => setForm({ ...form, website: e.target.value })}
            required
          />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <Label htmlFor="username">Username / Email *</Label>
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            id="username"
            placeholder="your-username"
            className="pl-10"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
            required
          />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="password">
            Password {isEditing ? "(leave blank to keep current)" : "*"}
          </Label>
          <Button
            type="button"
            variant="link"
            size="sm"
            className="h-auto p-0"
            onClick={() => setShowGenerator(!showGenerator)}
          >
            {showGenerator ? "Hide Generator" : "Generate Password"}
          </Button>
        </div>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            id="password"
            type="password"
            placeholder={isEditing ? "Enter new password or leave blank" : "Enter password"}
            className="pl-10"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required={!isEditing}
          />
        </div>
      </div>

      {showGenerator && (
        <div className="border rounded-lg p-4 bg-muted/30">
          <PasswordGenerator onUsePassword={handleUseGeneratedPassword} />
        </div>
      )}

      <div className="flex flex-col gap-2">
        <Label htmlFor="notes">Notes (optional)</Label>
        <div className="relative">
          <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <textarea
            id="notes"
            placeholder="Any additional notes..."
            className="min-h-[80px] w-full rounded-md border border-input bg-transparent pl-10 pr-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring resize-none"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
        </div>
      </div>

      <div className="flex flex-col gap-2 pt-2 border-t">
        <Label htmlFor="master-password">Master Password *</Label>
        <p className="text-xs text-muted-foreground">
          Required to encrypt/update this credential
        </p>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            id="master-password"
            type="password"
            placeholder="Your master password"
            className="pl-10"
            value={form.masterPassword}
            onChange={(e) => setForm({ ...form, masterPassword: e.target.value })}
            required
          />
        </div>
      </div>

      <div className="flex gap-3 pt-2">
        <Button type="button" variant="outline" onClick={handleClose} className="flex-1">
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading} className="flex-1">
          {isLoading ? <Spinner className="mr-2" /> : isEditing ? <Save className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
          {isEditing ? "Update" : "Save"} Credential
        </Button>
      </div>
    </form>
  )

  // If editing, render as inline card
  if (isEditing) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Edit Credential</CardTitle>
              <CardDescription>Update your saved credential</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {formContent}
        </CardContent>
      </Card>
    )
  }

  // Otherwise render as dialog trigger
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button size="lg">
          <Plus className="mr-2 h-4 w-4" />
          Add New Credential
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Credential</DialogTitle>
          <DialogDescription>
            Store a new password securely in your vault
          </DialogDescription>
        </DialogHeader>
        {formContent}
      </DialogContent>
    </Dialog>
  )
}
