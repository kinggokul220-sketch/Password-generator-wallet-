"use client"

import { useState } from "react"
import useSWR from "swr"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Spinner } from "@/components/ui/spinner"
import { getCredentials, decryptCredentialPassword, deleteCredential, type Credential } from "@/lib/api"
import { toast } from "sonner"
import { formatDistanceToNow } from "date-fns"
import { 
  Globe, 
  User, 
  Eye, 
  EyeOff, 
  Copy, 
  Trash2, 
  Edit, 
  Search,
  KeyRound,
  Lock
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

interface CredentialListProps {
  onEdit: (credential: Credential) => void
}

export function CredentialList({ onEdit }: CredentialListProps) {
  const { data, error, isLoading, mutate } = useSWR("credentials", async () => {
    const result = await getCredentials()
    return result.credentials
  })
  
  const [searchQuery, setSearchQuery] = useState("")
  const [visiblePasswords, setVisiblePasswords] = useState<Record<string, string>>({})
  const [loadingPasswords, setLoadingPasswords] = useState<Record<string, boolean>>({})
  const [masterPasswordDialog, setMasterPasswordDialog] = useState<{
    open: boolean
    credentialId: string
    action: "reveal" | "delete"
  }>({ open: false, credentialId: "", action: "reveal" })
  const [masterPassword, setMasterPassword] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const filteredCredentials = data?.filter((cred) =>
    cred.website.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cred.username.toLowerCase().includes(searchQuery.toLowerCase())
  ) || []

  const handleRevealPassword = (credentialId: string) => {
    if (visiblePasswords[credentialId]) {
      setVisiblePasswords((prev) => {
        const next = { ...prev }
        delete next[credentialId]
        return next
      })
    } else {
      setMasterPasswordDialog({
        open: true,
        credentialId,
        action: "reveal"
      })
    }
  }

  const handleDeleteClick = (credentialId: string) => {
    setMasterPasswordDialog({
      open: true,
      credentialId,
      action: "delete"
    })
  }

  const handleMasterPasswordSubmit = async () => {
    if (!masterPassword) {
      toast.error("Please enter your master password")
      return
    }

    setIsProcessing(true)
    const { credentialId, action } = masterPasswordDialog

    try {
      if (action === "reveal") {
        setLoadingPasswords((prev) => ({ ...prev, [credentialId]: true }))
        const result = await decryptCredentialPassword(credentialId, masterPassword)
        setVisiblePasswords((prev) => ({ ...prev, [credentialId]: result.password }))
        toast.success("Password revealed")
      } else if (action === "delete") {
        await deleteCredential(credentialId, masterPassword)
        toast.success("Credential deleted")
        mutate()
      }
      setMasterPasswordDialog({ open: false, credentialId: "", action: "reveal" })
      setMasterPassword("")
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Operation failed")
    } finally {
      setIsProcessing(false)
      setLoadingPasswords((prev) => ({ ...prev, [credentialId]: false }))
    }
  }

  const handleCopyPassword = async (credentialId: string) => {
    const password = visiblePasswords[credentialId]
    if (!password) {
      toast.error("Please reveal the password first")
      return
    }
    
    try {
      await navigator.clipboard.writeText(password)
      toast.success("Password copied to clipboard")
    } catch {
      toast.error("Failed to copy password")
    }
  }

  const handleCopyUsername = async (username: string) => {
    try {
      await navigator.clipboard.writeText(username)
      toast.success("Username copied to clipboard")
    } catch {
      toast.error("Failed to copy username")
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Spinner className="h-8 w-8" />
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12 gap-4">
          <p className="text-destructive">Failed to load credentials</p>
          <Button variant="outline" onClick={() => mutate()}>
            Try Again
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <KeyRound className="h-5 w-5" />
            Saved Passwords
          </CardTitle>
          <CardDescription>
            {data?.length || 0} credentials stored securely
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search credentials..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Credential List */}
          {filteredCredentials.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              {data?.length === 0 ? (
                <p>No credentials saved yet. Add your first password!</p>
              ) : (
                <p>No credentials match your search.</p>
              )}
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {filteredCredentials.map((credential) => (
                <div
                  key={credential.id}
                  className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Globe className="h-4 w-4 text-muted-foreground shrink-0" />
                      <span className="font-medium truncate">{credential.website}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <User className="h-3 w-3 shrink-0" />
                      <span 
                        className="truncate cursor-pointer hover:text-foreground"
                        onClick={() => handleCopyUsername(credential.username)}
                        title="Click to copy username"
                      >
                        {credential.username}
                      </span>
                    </div>
                    {/* Password Display */}
                    <div className="flex items-center gap-2 mt-2">
                      <Lock className="h-3 w-3 text-muted-foreground shrink-0" />
                      <span className="font-mono text-sm">
                        {loadingPasswords[credential.id] ? (
                          <Spinner className="h-3 w-3" />
                        ) : visiblePasswords[credential.id] ? (
                          visiblePasswords[credential.id]
                        ) : (
                          "••••••••••••"
                        )}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Updated {formatDistanceToNow(new Date(credential.updated_at))} ago
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-2 shrink-0">
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      onClick={() => handleRevealPassword(credential.id)}
                      title={visiblePasswords[credential.id] ? "Hide password" : "Show password"}
                    >
                      {visiblePasswords[credential.id] ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      onClick={() => handleCopyPassword(credential.id)}
                      disabled={!visiblePasswords[credential.id]}
                      title="Copy password"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      onClick={() => onEdit(credential)}
                      title="Edit credential"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      onClick={() => handleDeleteClick(credential.id)}
                      title="Delete credential"
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Master Password Dialog */}
      <Dialog 
        open={masterPasswordDialog.open} 
        onOpenChange={(open) => {
          if (!open) {
            setMasterPasswordDialog({ open: false, credentialId: "", action: "reveal" })
            setMasterPassword("")
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {masterPasswordDialog.action === "reveal" 
                ? "Enter Master Password" 
                : "Confirm Deletion"}
            </DialogTitle>
            <DialogDescription>
              {masterPasswordDialog.action === "reveal"
                ? "Enter your master password to reveal this password."
                : "Enter your master password to confirm deletion. This action cannot be undone."}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="master-password">Master Password</Label>
              <Input
                id="master-password"
                type="password"
                placeholder="Enter your master password"
                value={masterPassword}
                onChange={(e) => setMasterPassword(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleMasterPasswordSubmit()
                  }
                }}
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setMasterPasswordDialog({ open: false, credentialId: "", action: "reveal" })
                setMasterPassword("")
              }}
            >
              Cancel
            </Button>
            <Button 
              variant={masterPasswordDialog.action === "delete" ? "destructive" : "default"}
              onClick={handleMasterPasswordSubmit}
              disabled={isProcessing}
            >
              {isProcessing ? <Spinner className="mr-2" /> : null}
              {masterPasswordDialog.action === "reveal" ? "Reveal" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
