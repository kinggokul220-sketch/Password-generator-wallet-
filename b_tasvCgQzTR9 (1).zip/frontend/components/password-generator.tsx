"use client"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import { Spinner } from "@/components/ui/spinner"
import { generatePassword, type GeneratedPassword, type PasswordOptions } from "@/lib/api"
import { toast } from "sonner"
import { RefreshCw, Copy, Check, Wand2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface PasswordGeneratorProps {
  onUsePassword?: (password: string) => void
}

export function PasswordGenerator({ onUsePassword }: PasswordGeneratorProps) {
  const [options, setOptions] = useState<PasswordOptions>({
    length: 16,
    includeUppercase: true,
    includeLowercase: true,
    includeNumbers: true,
    includeSymbols: true,
  })
  
  const [result, setResult] = useState<GeneratedPassword | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleGenerate = useCallback(async () => {
    setIsLoading(true)
    try {
      const data = await generatePassword(options)
      setResult(data)
      setCopied(false)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to generate password")
    } finally {
      setIsLoading(false)
    }
  }, [options])

  const handleCopy = async () => {
    if (!result?.password) return
    
    try {
      await navigator.clipboard.writeText(result.password)
      setCopied(true)
      toast.success("Password copied to clipboard")
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast.error("Failed to copy password")
    }
  }

  const handleUsePassword = () => {
    if (result?.password && onUsePassword) {
      onUsePassword(result.password)
    }
  }

  const getStrengthColor = (level: string) => {
    switch (level) {
      case "strong":
        return "bg-accent"
      case "medium":
        return "bg-yellow-500"
      default:
        return "bg-destructive"
    }
  }

  const getStrengthText = (level: string) => {
    switch (level) {
      case "strong":
        return "Strong"
      case "medium":
        return "Medium"
      default:
        return "Weak"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wand2 className="h-5 w-5" />
          Password Generator
        </CardTitle>
        <CardDescription>
          Generate strong, secure passwords with custom options
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-6">
        {/* Generated Password Display */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <div className="flex-1 rounded-lg border bg-muted/50 p-4 font-mono text-lg break-all min-h-[60px] flex items-center">
              {result?.password || (
                <span className="text-muted-foreground">Click generate to create a password</span>
              )}
            </div>
            <div className="flex flex-col gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={handleCopy}
                disabled={!result?.password}
                title="Copy to clipboard"
              >
                {copied ? <Check className="h-4 w-4 text-accent" /> : <Copy className="h-4 w-4" />}
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={handleGenerate}
                disabled={isLoading}
                title="Generate new password"
              >
                {isLoading ? <Spinner /> : <RefreshCw className="h-4 w-4" />}
              </Button>
            </div>
          </div>
          
          {/* Strength Indicator */}
          {result?.strength && (
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Password Strength</span>
                <span className={cn(
                  "font-medium",
                  result.strength.level === "strong" && "text-accent",
                  result.strength.level === "medium" && "text-yellow-500",
                  result.strength.level === "weak" && "text-destructive"
                )}>
                  {getStrengthText(result.strength.level)}
                </span>
              </div>
              <Progress 
                value={(result.strength.score / result.strength.maxScore) * 100} 
                className={cn("h-2", getStrengthColor(result.strength.level))}
              />
              {result.strength.feedback.length > 0 && (
                <ul className="text-xs text-muted-foreground list-disc list-inside">
                  {result.strength.feedback.map((tip, i) => (
                    <li key={i}>{tip}</li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>

        {/* Options */}
        <div className="flex flex-col gap-4">
          {/* Length Slider */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <Label>Password Length</Label>
              <span className="text-sm font-mono bg-muted px-2 py-1 rounded">
                {options.length}
              </span>
            </div>
            <Slider
              value={[options.length]}
              onValueChange={([value]) => setOptions({ ...options, length: value })}
              min={4}
              max={64}
              step={1}
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>4</span>
              <span>64</span>
            </div>
          </div>

          {/* Character Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label htmlFor="uppercase" className="cursor-pointer">
                Uppercase (A-Z)
              </Label>
              <Switch
                id="uppercase"
                checked={options.includeUppercase}
                onCheckedChange={(checked) => 
                  setOptions({ ...options, includeUppercase: checked })
                }
              />
            </div>
            
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label htmlFor="lowercase" className="cursor-pointer">
                Lowercase (a-z)
              </Label>
              <Switch
                id="lowercase"
                checked={options.includeLowercase}
                onCheckedChange={(checked) => 
                  setOptions({ ...options, includeLowercase: checked })
                }
              />
            </div>
            
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label htmlFor="numbers" className="cursor-pointer">
                Numbers (0-9)
              </Label>
              <Switch
                id="numbers"
                checked={options.includeNumbers}
                onCheckedChange={(checked) => 
                  setOptions({ ...options, includeNumbers: checked })
                }
              />
            </div>
            
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label htmlFor="symbols" className="cursor-pointer">
                Symbols (!@#$...)
              </Label>
              <Switch
                id="symbols"
                checked={options.includeSymbols}
                onCheckedChange={(checked) => 
                  setOptions({ ...options, includeSymbols: checked })
                }
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button onClick={handleGenerate} disabled={isLoading} className="flex-1">
            {isLoading ? <Spinner className="mr-2" /> : <Wand2 className="mr-2 h-4 w-4" />}
            Generate Password
          </Button>
          {onUsePassword && result?.password && (
            <Button variant="secondary" onClick={handleUsePassword}>
              Use This Password
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
