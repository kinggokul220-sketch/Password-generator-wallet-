const getAuthHeaders = () => {
  const token = typeof window !== "undefined" ? localStorage.getItem("auth_token") : null
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  }
}

export interface PasswordOptions {
  length: number
  includeUppercase: boolean
  includeLowercase: boolean
  includeNumbers: boolean
  includeSymbols: boolean
}

export interface GeneratedPassword {
  password: string
  strength: {
    score: number
    maxScore: number
    level: "weak" | "medium" | "strong"
    feedback: string[]
  }
}

export interface Credential {
  id: string
  website: string
  username: string
  notes: string
  created_at: string
  updated_at: string
}

export async function generatePassword(options: PasswordOptions): Promise<GeneratedPassword> {
  const res = await fetch("/api/generate-password", {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(options),
  })
  
  if (!res.ok) {
    const error = await res.json()
    throw new Error(error.error || "Failed to generate password")
  }
  
  return res.json()
}

export async function getCredentials(): Promise<{ credentials: Credential[] }> {
  const res = await fetch("/api/credentials", {
    headers: getAuthHeaders(),
  })
  
  if (!res.ok) {
    const error = await res.json()
    throw new Error(error.error || "Failed to fetch credentials")
  }
  
  return res.json()
}

export async function createCredential(data: {
  website: string
  username: string
  password: string
  notes?: string
  masterPassword: string
}): Promise<{ credential: Credential }> {
  const res = await fetch("/api/credentials", {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(data),
  })
  
  if (!res.ok) {
    const error = await res.json()
    throw new Error(error.error || "Failed to create credential")
  }
  
  return res.json()
}

export async function decryptCredentialPassword(
  credentialId: string,
  masterPassword: string
): Promise<{ password: string }> {
  const res = await fetch(`/api/credentials/${credentialId}/decrypt`, {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify({ masterPassword }),
  })
  
  if (!res.ok) {
    const error = await res.json()
    throw new Error(error.error || "Failed to decrypt password")
  }
  
  return res.json()
}

export async function updateCredential(
  credentialId: string,
  data: {
    website?: string
    username?: string
    password?: string
    notes?: string
    masterPassword: string
  }
): Promise<{ credential: Credential }> {
  const res = await fetch(`/api/credentials/${credentialId}`, {
    method: "PUT",
    headers: getAuthHeaders(),
    body: JSON.stringify(data),
  })
  
  if (!res.ok) {
    const error = await res.json()
    throw new Error(error.error || "Failed to update credential")
  }
  
  return res.json()
}

export async function deleteCredential(
  credentialId: string,
  masterPassword: string
): Promise<void> {
  const res = await fetch(`/api/credentials/${credentialId}`, {
    method: "DELETE",
    headers: getAuthHeaders(),
    body: JSON.stringify({ masterPassword }),
  })
  
  if (!res.ok) {
    const error = await res.json()
    throw new Error(error.error || "Failed to delete credential")
  }
}
